# Sanctuary 3.2 — The Local-First Socratic CBT Core

> **Instant, Private, Clinical-Grade CBT Reasoning — Powered by Gemma 4.**

Sanctuary is a production-hardened, zero-telemetry mental health journaling platform that brings high-fidelity therapeutic support to the edge. Built for the privacy-conscious user, Sanctuary processes everything—from voice transcriptions to clinical reasoning—100% locally on your device. No API keys. No cloud calls. No data leaks.

---

## Key Innovations

### 1. Zero-Telemetry Architecture
No API keys. No cloud processing. No data leaks. Sanctuary uses an optimized **Gemma 4 E4B** fine-tuned model for local inference via `llama-cpp-python`, achieving **5.05 tokens/second on CPU** with a lightweight **2.49 GB** model footprint.

### 2. HyDE-RAG (Hypothetical Document Embeddings)
Our RAG engine doesn't just search; it *reasons*. By generating a hypothetical clinical response before querying our **ChromaDB** clinical protocol vault, Sanctuary achieves state-of-the-art retrieval relevance for complex emotional queries, refined further by a local **Cross-Encoder Reranker**.

### 3. Socratic CBT Reasoning Engine
Unlike generic LLMs that provide "advice," Sanctuary is strictly programmed for **Socratic Reframing**:
- **Identifying Cognitive Distortions**: Automatically tags distortions like *Catastrophizing*, *Emotional Reasoning*, and *All-or-Nothing Thinking*.
- **Chain-of-Thought**: The fine-tuned model internally reasons about the specific distortion before generating a Socratic response, with structural headers stripped on-the-fly for a premium UX.
- **Protocol Adherence**: All reasoning is grounded in a local vault of clinical CBT protocols.

### 4. Tiered Safety Hierarchy
- **Level 1**: Real-time keyword crisis detection → immediate 988 Lifeline redirect.
- **Level 2**: Behavioral biometric analysis (typing cadence & acoustic jitter).
- **Level 3**: Clinical grounding via HyDE-RAG injection for severe distress.

### 5. Premium Glassmorphic UX
A high-fidelity, Spotify-inspired glassmorphic UI built with **Next.js 16** and **Tailwind CSS v4**, featuring:
- **IndexedDB Persistence**: Offline draft caching with zero cloud dependency.
- **Audio Visualizer**: Real-time canvas-based frequency analysis for voice sessions.
- **Secure Vault**: AES-256 GCM encrypted journal storage with biometric jittering.

---

## Technical Stack

| Layer | Technology |
| :--- | :--- |
| **ML Core** | Gemma 4 E4B (Unsloth rsLoRA fine-tune) via `llama-cpp-python` |
| **Vector DB** | ChromaDB + `all-MiniLM-L6-v2` + Cross-Encoder Reranker |
| **Audio** | Silero VAD (ONNX) + OpenAI Whisper (Local) |
| **Frontend** | Next.js 16, Framer Motion, Lucide, ReactMarkdown |
| **Backend** | FastAPI, AnyIO, Cryptography (AES-256 GCM) |
| **Design** | Premium Glassmorphism, Tailwind CSS v4, Mesh Backgrounds |

---

## Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+
- ~4 GB free disk space

### 1. Download the Model
Download `sanctuary_cbt_final.gguf` (2.49 GB) and place it in `backend/models/`:
```
backend/models/sanctuary_cbt_final.gguf
```

### 2. Backend
```bash
cd backend
python -m venv env
.\env\Scripts\activate       # Windows
# source env/bin/activate    # macOS/Linux
pip install -r requirements.txt
python server.py
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev
```
Access Sanctuary at: **http://localhost:3000**

### 4. Docker (One-Command)
```bash
# Place sanctuary_cbt_final.gguf in backend/models/ first
docker-compose up --build
```

---

## Hardware Requirements

| Component | Minimum | Recommended |
| :--- | :--- | :--- |
| **CPU** | Intel i5 / Ryzen 5 | Intel i7 / Ryzen 7 |
| **RAM** | 8 GB | 16 GB |
| **Storage** | 4 GB free SSD | 10 GB free SSD |
| **GPU** | Not required | Optional CUDA GPU |

---

## Privacy Commitment
Sanctuary is built on the principle that **mental health data is sacred**. Not a single byte of your chat history, voice recordings, or biometrics will ever leave your machine. All data is encrypted at rest with AES-256 GCM.

---

**Sanctuary — Because your mind deserves a private place.**
